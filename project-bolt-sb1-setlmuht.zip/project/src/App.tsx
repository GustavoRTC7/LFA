import { useMemo, useState } from "react";
import {
  ShieldCheck,
  ShieldAlert,
  Send,
  BookOpen,
  Trash2,
  Sparkles,
  UserX,
  AlertTriangle,
  Ban,
  CheckCircle2,
  Info,
  ChevronRight,
} from "lucide-react";
import { analyze } from "@/expert/inferenceEngine";
import { KNOWLEDGE_BASE } from "@/expert/knowledgeBase";
import type { AnalysisResult, InputFacts } from "@/expert/types";

interface Example {
  label: string;
  message: string;
  unknownSender: boolean;
  hint: string;
}

const EXAMPLES: Example[] = [
  {
    label: "Golpe bancário",
    hint: "Phishing",
    message:
      "URGENTE: Sua conta foi BLOQUEADA por atividades suspeitas. Acesse http://bit.ly/recupera-senha para reativar sua fatura e evitar o cancelamento do PIX.",
    unknownSender: true,
  },
  {
    label: "Promoção spam",
    hint: "Spam comercial",
    message:
      "Você GANHOU um prêmio exclusivo! Resgate grátis seu cupom de desconto de 90% na loja. Promoção por tempo limitado!",
    unknownSender: true,
  },
  {
    label: "Mensagem de trabalho",
    hint: "Legítima",
    message:
      "Oi equipe, segue o resumo da reunião de hoje. Precisamos finalizar o relatório até sexta. Abraços.",
    unknownSender: false,
  },
];

const ALERT_THEME = {
  red: {
    ring: "ring-red-500/40",
    bg: "bg-red-50",
    border: "border-red-200",
    text: "text-red-700",
    label: "text-red-800",
    bar: "bg-red-500",
    icon: Ban,
    badge: "bg-red-100 text-red-700 border-red-200",
  },
  orange: {
    ring: "ring-orange-500/40",
    bg: "bg-orange-50",
    border: "border-orange-200",
    text: "text-orange-700",
    label: "text-orange-800",
    bar: "bg-orange-500",
    icon: AlertTriangle,
    badge: "bg-orange-100 text-orange-700 border-orange-200",
  },
  yellow: {
    ring: "ring-yellow-500/40",
    bg: "bg-yellow-50",
    border: "border-yellow-200",
    text: "text-yellow-700",
    label: "text-yellow-800",
    bar: "bg-yellow-500",
    icon: AlertTriangle,
    badge: "bg-yellow-100 text-yellow-700 border-yellow-200",
  },
  green: {
    ring: "ring-emerald-500/40",
    bg: "bg-emerald-50",
    border: "border-emerald-200",
    text: "text-emerald-700",
    label: "text-emerald-800",
    bar: "bg-emerald-500",
    icon: CheckCircle2,
    badge: "bg-emerald-100 text-emerald-700 border-emerald-200",
  },
} as const;

const LEVEL_LABEL: Record<AnalysisResult["level"], string> = {
  alto: "Risco Alto — Phishing",
  medio: "Risco Médio — Spam Comercial",
  baixo: "Risco Baixo — Spam de Ruído",
  legitima: "Mensagem Legítima",
};

function App() {
  const [message, setMessage] = useState("");
  const [unknownSender, setUnknownSender] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [activeTab, setActiveTab] = useState<"analise" | "base">("analise");

  const facts: InputFacts = useMemo(
    () => ({ message, unknownSender }),
    [message, unknownSender],
  );

  function handleAnalyze() {
    setResult(analyze(facts));
    setActiveTab("analise");
  }

  function handleClear() {
    setMessage("");
    setUnknownSender(false);
    setResult(null);
  }

  function loadExample(ex: Example) {
    setMessage(ex.message);
    setUnknownSender(ex.unknownSender);
    setResult(null);
  }

  const theme = result ? ALERT_THEME[result.alertColor] : ALERT_THEME.green;
  const VerdictIcon = theme.icon;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800">
      {/* Header */}
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-900 text-white shadow-sm">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 sm:text-xl">
                GuardIA
              </h1>
              <p className="text-xs text-slate-500 sm:text-sm">
                Sistema Especialista de Filtragem de Mensagens
              </p>
            </div>
          </div>
          <div className="hidden items-center gap-2 rounded-full bg-slate-100 px-3 py-1.5 text-xs font-medium text-slate-600 sm:flex">
            <Sparkles className="h-3.5 w-3.5 text-slate-400" />
            Inteligência Artificial · Acadêmico
          </div>
        </div>

        {/* Tabs */}
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <nav className="flex gap-1">
            <TabButton
              active={activeTab === "analise"}
              onClick={() => setActiveTab("analise")}
              icon={<ShieldAlert className="h-4 w-4" />}
              label="Análise"
            />
            <TabButton
              active={activeTab === "base"}
              onClick={() => setActiveTab("base")}
              icon={<BookOpen className="h-4 w-4" />}
              label="Base de Conhecimento"
            />
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8 sm:px-6">
        {activeTab === "analise" ? (
          <div className="grid gap-6 lg:grid-cols-5">
            {/* Input */}
            <section className="lg:col-span-3">
              <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-6">
                <div className="mb-4 flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-semibold text-slate-900">
                      Área de Entrada — Fatos
                    </h2>
                    <p className="mt-0.5 text-sm text-slate-500">
                      Cole a mensagem a ser avaliada pelo motor de inferência.
                    </p>
                  </div>
                  <button
                    onClick={handleClear}
                    className="inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-slate-500 transition hover:bg-slate-100 hover:text-slate-700"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Limpar
                  </button>
                </div>

                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={6}
                  placeholder="Ex: URGENTE: sua conta foi bloqueada. Acesse http://bit.ly/salvar-conta ..."
                  className="w-full resize-y rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm leading-relaxed text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-slate-400 focus:bg-white focus:ring-2 focus:ring-slate-900/10"
                />

                <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 transition hover:bg-slate-100">
                  <input
                    type="checkbox"
                    checked={unknownSender}
                    onChange={(e) => setUnknownSender(e.target.checked)}
                    className="mt-0.5 h-4 w-4 rounded border-slate-300 text-slate-900 focus:ring-slate-900/20"
                  />
                  <span className="flex items-center gap-1.5 text-sm font-medium text-slate-700">
                    <UserX className="h-4 w-4 text-slate-400" />
                    Remetente desconhecido
                  </span>
                </label>

                {/* Examples */}
                <div className="mt-5">
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Testar exemplo
                  </p>
                  <div className="grid gap-2 sm:grid-cols-3">
                    {EXAMPLES.map((ex) => (
                      <button
                        key={ex.label}
                        onClick={() => loadExample(ex)}
                        className="group flex flex-col items-start gap-1 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-left transition hover:border-slate-300 hover:bg-slate-50 hover:shadow-sm"
                      >
                        <span className="text-sm font-medium text-slate-800">
                          {ex.label}
                        </span>
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-400 group-hover:text-slate-500">
                          <ChevronRight className="h-3 w-3" />
                          {ex.hint}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleAnalyze}
                  disabled={message.trim().length === 0}
                  className="mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-slate-900 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-slate-800 disabled:cursor-not-allowed disabled:opacity-40"
                >
                  <Send className="h-4 w-4" />
                  Analisar Mensagem
                </button>
              </div>
            </section>

            {/* Result */}
            <section className="lg:col-span-2">
              <div
                className={`overflow-hidden rounded-2xl border ${theme.border} bg-white shadow-sm ring-2 ${theme.ring}`}
              >
                <div className={`h-1.5 w-full ${theme.bar}`} />
                <div className="p-5 sm:p-6">
                  {result ? (
                    <>
                      <div className="flex items-center gap-3">
                        <div
                          className={`flex h-12 w-12 items-center justify-center rounded-xl ${theme.bg} ${theme.text}`}
                        >
                          <VerdictIcon className="h-6 w-6" />
                        </div>
                        <div>
                          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
                            Veredito
                          </p>
                          <p className={`text-base font-bold ${theme.label}`}>
                            {LEVEL_LABEL[result.level]}
                          </p>
                        </div>
                      </div>

                      {/* Rule fired */}
                      <div className="mt-5">
                        <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-slate-400">
                          Regra Disparada
                        </p>
                        <div
                          className={`rounded-xl border ${theme.border} ${theme.bg} px-4 py-3`}
                        >
                          <p className={`text-sm font-semibold ${theme.label}`}>
                            {result.rule.name}
                          </p>
                          <p
                            className={`mt-1 text-sm leading-relaxed ${theme.text}`}
                          >
                            {result.rule.statement}
                          </p>
                        </div>
                      </div>

                      {/* Identified facts */}
                      <div className="mt-5">
                        <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">
                          Fatos Identificados
                        </p>
                        <ul className="space-y-2.5">
                          {result.rule.facts.map((fact, i) => (
                            <li
                              key={i}
                              className="rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-3"
                            >
                              <p className="text-sm font-semibold text-slate-800">
                                {fact.pattern}
                              </p>
                              {fact.matches.length > 0 && (
                                <div className="mt-1.5 flex flex-wrap gap-1.5">
                                  {fact.matches.map((m, j) => (
                                    <span
                                      key={j}
                                      className={`rounded-md border px-2 py-0.5 text-xs font-medium ${theme.badge}`}
                                    >
                                      {m}
                                    </span>
                                  ))}
                                </div>
                              )}
                              <p className="mt-1.5 text-xs leading-relaxed text-slate-500">
                                {fact.reason}
                              </p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center">
                      <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
                        <Info className="h-7 w-7" />
                      </div>
                      <p className="mt-4 text-sm font-medium text-slate-600">
                        Aguardando análise
                      </p>
                      <p className="mt-1 max-w-xs text-xs text-slate-400">
                        Cole uma mensagem e clique em “Analisar Mensagem” para
                        ver o veredito do motor de inferência.
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </section>
          </div>
        ) : (
          <KnowledgeBaseView />
        )}
      </main>

      <footer className="border-t border-slate-200 bg-white">
        <div className="mx-auto max-w-6xl px-4 py-6 text-center text-xs text-slate-400 sm:px-6">
          GuardIA · Projeto acadêmico de Inteligência Artificial — Sistema
          Especialista com encadeamento progressivo.
        </div>
      </footer>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`relative flex items-center gap-2 px-4 py-3 text-sm font-medium transition ${
        active
          ? "text-slate-900"
          : "text-slate-500 hover:text-slate-700"
      }`}
    >
      {icon}
      {label}
      <span
        className={`absolute inset-x-0 bottom-0 h-0.5 rounded-full transition ${
          active ? "bg-slate-900" : "bg-transparent"
        }`}
      />
    </button>
  );
}

const KB_THEME = {
  alto: ALERT_THEME.red,
  medio: ALERT_THEME.orange,
  baixo: ALERT_THEME.yellow,
  legitima: ALERT_THEME.green,
} as const;

function KnowledgeBaseView() {
  return (
    <div>
      <div className="mb-6 max-w-2xl">
        <h2 className="text-xl font-bold text-slate-900">Base de Conhecimento</h2>
        <p className="mt-1 text-sm text-slate-500">
          As regras abaixo formam o conhecimento do especialista. O motor de
          inferência as avalia em ordem de prioridade (1 → 4) usando
          encadeamento progressivo.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {KNOWLEDGE_BASE.map((rule, i) => {
          const t = KB_THEME[rule.level];
          const Icon = t.icon;
          return (
            <div
              key={rule.id}
              className={`overflow-hidden rounded-2xl border ${t.border} bg-white shadow-sm`}
            >
              <div className={`h-1.5 w-full ${t.bar}`} />
              <div className="p-5">
                <div className="flex items-start gap-3">
                  <div
                    className={`flex h-10 w-10 flex-none items-center justify-center rounded-xl ${t.bg} ${t.text}`}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <div>
                    <span className="text-[11px] font-semibold uppercase tracking-wide text-slate-400">
                      Regra {i + 1}
                    </span>
                    <h3 className={`text-base font-bold ${t.label}`}>
                      {rule.name.replace(/^Regra \d+ — /, "")}
                    </h3>
                  </div>
                </div>

                <p className="mt-3 text-sm leading-relaxed text-slate-600">
                  {rule.description}
                </p>

                <div
                  className={`mt-4 rounded-xl border ${t.border} ${t.bg} px-4 py-3`}
                >
                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-400">
                    Produção
                  </p>
                  <p className={`mt-1 text-sm leading-relaxed ${t.text}`}>
                    {rule.statement}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 flex items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-600">
        <Info className="mt-0.5 h-4 w-4 flex-none text-slate-400" />
        <p>
          <strong className="text-slate-700">Encadeamento progressivo:</strong>{" "}
          o motor parte dos fatos de entrada (texto + remetente) e dispara a
          primeira regra cujas condições forem satisfeitas. A regra 4 é a
          cláusula padrão — só é alcançada se nenhuma outra disparar.
        </p>
      </div>
    </div>
  );
}

export default App;
