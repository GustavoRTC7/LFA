import type { KnowledgeRule } from "./types";

/**
 * Base de Conhecimento do GuardIA.
 *
 * Um Sistema Especialista clássico armazena o conhecimento de um
 * especialista humano na forma de regras de produção (SE ... ENTÃO ...).
 * Estas três regras + a regra padrão (legítima) formam toda a lógica de
 * filtragem do sistema.
 */
export const KNOWLEDGE_BASE: KnowledgeRule[] = [
  {
    id: "regra-1",
    name: "Regra 1 — Phishing / Golpe",
    description:
      "Detecta mensagens que combinam linguagem de urgência ou financeira com a presença de um link suspeito.",
    statement:
      "SE a mensagem contiver termos de urgência/financeiro (\"bloqueado\", \"urgente\", \"pix\", \"senha\", \"fatura\") E contiver um link (\"http\", \"bit.ly\", \".com\", \"clique aqui\") ENTÃO Risco Alto (Phishing).",
    level: "alto",
  },
  {
    id: "regra-2",
    name: "Regra 2 — Spam Comercial",
    description:
      "Detecta mensagens promocionais vindas de remetentes desconhecidos.",
    statement:
      "SE a mensagem contiver termos promocionais (\"ganhou\", \"prêmio\", \"grátis\", \"promoção\", \"desconto\") E o remetente for desconhecido ENTÃO Risco Médio (Spam).",
    level: "medio",
  },
  {
    id: "regra-3",
    name: "Regra 3 — Ruído / Agressividade",
    description:
      "Detecta mensagens agressivas visualmente: excesso de maiúsculas ou exclamações.",
    statement:
      "SE mais de 40% das letras estiverem em MAIÚSCULAS OU houver excesso de exclamações (\"!!!\") ENTÃO Risco Baixo (Spam de Ruído).",
    level: "baixo",
  },
  {
    id: "regra-4",
    name: "Regra 4 — Mensagem Legítima",
    description:
      "Regra padrão (default): se nenhuma regra anterior for satisfeita, a mensagem é considerada segura.",
    statement:
      "SE nenhuma das regras anteriores for satisfeita ENTÃO a mensagem é Legítima.",
    level: "legitima",
  },
];
