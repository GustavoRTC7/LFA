import type {
  AnalysisResult,
  IdentifiedFact,
  InputFacts,
  RuleFired,
} from "./types";
import { KNOWLEDGE_BASE } from "./knowledgeBase";

/**
 * Motor de Inferência do GuardIA.
 *
 * Implementa encadeamento progressivo (forward chaining): parte dos fatos
 * de entrada (texto da mensagem + remetente desconhecido) e percorre a
 * base de conhecimento em ordem de prioridade. A primeira regra cujas
 * condições são satisfeitas "dispara" e define o veredito.
 *
 * As regras são avaliadas na ordem 1 → 4, da mais grave para a mais branda,
 * de modo que uma mensagem de phishing que também contenha promoções seja
 * classificada como Risco Alto (phishing tem prioridade).
 */

const URGENT_FINANCIAL_TERMS = [
  "bloqueado",
  "urgente",
  "pix",
  "senha",
  "fatura",
];

const LINK_PATTERNS = ["http", "bit.ly", ".com", "clique aqui"];

const PROMOTIONAL_TERMS = [
  "ganhou",
  "prêmio",
  "premio",
  "grátis",
  "gratis",
  "promoção",
  "promocao",
  "desconto",
];

const CAPS_RATIO_THRESHOLD = 0.4;

function findTerms(text: string, terms: string[]): string[] {
  const lower = text.toLowerCase();
  return terms.filter((term) => lower.includes(term.toLowerCase()));
}

function capsRatio(text: string): number {
  const letters = text.replace(/[^a-zA-ZÀ-ÿ]/g, "");
  if (letters.length === 0) return 0;
  const upper = letters.replace(/[^A-ZÀ-ÖØ-Þ]/g, "");
  return upper.length / letters.length;
}

function hasExcessExclamations(text: string): boolean {
  return /!{3,}/.test(text);
}

function factsForRule1(input: InputFacts): IdentifiedFact[] | null {
  const terms = findTerms(input.message, URGENT_FINANCIAL_TERMS);
  const links = findTerms(input.message, LINK_PATTERNS);

  if (terms.length === 0 || links.length === 0) return null;

  return [
    {
      pattern: "Termos de urgência / financeiro",
      matches: terms,
      reason:
        "A mensagem usa vocabulário típico de golpes que pressiona a vítima a agir rápido.",
    },
    {
      pattern: "Link suspeito presente",
      matches: links,
      reason:
        "A presença de um link combinada com urgência é o padrão clássico de phishing.",
    },
  ];
}

function factsForRule2(input: InputFacts): IdentifiedFact[] | null {
  const terms = findTerms(input.message, PROMOTIONAL_TERMS);

  if (terms.length === 0 || !input.unknownSender) return null;

  return [
    {
      pattern: "Termos promocionais",
      matches: terms,
      reason:
        "A mensagem usa linguagem típica de marketing agressivo / isca de prêmio.",
    },
    {
      pattern: "Remetente desconhecido",
      matches: ["Remetente desconhecido marcado"],
      reason:
        "Ofertas vindas de contatos não identificados têm alta probabilidade de serem spam.",
    },
  ];
}

function factsForRule3(input: InputFacts): IdentifiedFact[] | null {
  const facts: IdentifiedFact[] = [];
  const ratio = capsRatio(input.message);
  const excessExcl = hasExcessExclamations(input.message);

  if (ratio <= CAPS_RATIO_THRESHOLD && !excessExcl) return null;

  if (ratio > CAPS_RATIO_THRESHOLD) {
    facts.push({
      pattern: `Proporção de MAIÚSCULAS > ${Math.round(
        CAPS_RATIO_THRESHOLD * 100,
      )}%`,
      matches: [`${Math.round(ratio * 100)}% das letras em maiúsculas`],
      reason:
        "O uso excessivo de maiúsculas transmite agressividade e é comum em correntes / spam de ruído.",
    });
  }

  if (excessExcl) {
    const matches = input.message.match(/!{3,}/g) ?? [];
    facts.push({
      pattern: "Excesso de exclamações (!!!)",
      matches,
      reason:
        "Sequências de exclamações reforçam o caráter sensacionalista da mensagem.",
    });
  }

  return facts;
}

function ruleById(id: (typeof KNOWLEDGE_BASE)[number]["id"]): RuleFired {
  const base = KNOWLEDGE_BASE.find((r) => r.id === id)!;
  return { ...base, facts: [] };
}

function buildResult(
  id: (typeof KNOWLEDGE_BASE)[number]["id"],
  facts: IdentifiedFact[],
): AnalysisResult {
  const base = KNOWLEDGE_BASE.find((r) => r.id === id)!;
  const rule: RuleFired = { ...base, facts };
  const alertColor: AnalysisResult["alertColor"] =
    base.level === "alto"
      ? "red"
      : base.level === "medio"
        ? "orange"
        : base.level === "baixo"
          ? "yellow"
          : "green";
  return { level: base.level, rule, alertColor };
}

/**
 * Executa o encadeamento progressivo sobre a base de conhecimento.
 * Retorna o primeiro veredito cujas condições são satisfeitas.
 */
export function analyze(input: InputFacts): AnalysisResult {
  const trimmed = input.message.trim();
  if (trimmed.length === 0) {
    return buildResult("regra-4", [
      {
        pattern: "Mensagem vazia",
        matches: [],
        reason: "Nenhuma regra pode ser avaliada sem conteúdo de entrada.",
      },
    ]);
  }

  const safeInput: InputFacts = { ...input, message: trimmed };

  const r1 = factsForRule1(safeInput);
  if (r1) return buildResult("regra-1", r1);

  const r2 = factsForRule2(safeInput);
  if (r2) return buildResult("regra-2", r2);

  const r3 = factsForRule3(safeInput);
  if (r3) return buildResult("regra-3", r3);

  return buildResult("regra-4", [
    {
      pattern: "Nenhum padrão suspeito detectado",
      matches: [],
      reason:
        "A mensagem não atende aos critérios de phishing, spam comercial nem ruído.",
    },
  ]);
}
