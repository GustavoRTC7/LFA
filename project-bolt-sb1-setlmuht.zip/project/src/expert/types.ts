export type RiskLevel = "alto" | "medio" | "baixo" | "legitima";

export type RuleId = "regra-1" | "regra-2" | "regra-3" | "regra-4";

export interface IdentifiedFact {
  /** The pattern or keyword that matched, as the user sees it. */
  pattern: string;
  /** The actual snippet(s) found in the message. */
  matches: string[];
  /** Human-readable reason why this fact matters. */
  reason: string;
}

export interface RuleFired {
  id: RuleId;
  name: string;
  description: string;
  /** The full "SE ... ENTÃO ..." statement, rendered for explainability. */
  statement: string;
  level: RiskLevel;
  /** Facts that contributed to firing this rule. */
  facts: IdentifiedFact[];
}

export interface AnalysisResult {
  level: RiskLevel;
  rule: RuleFired;
  /** Color bucket used by the UI (matches level). */
  alertColor: "red" | "orange" | "yellow" | "green";
}

export interface KnowledgeRule {
  id: RuleId;
  name: string;
  description: string;
  statement: string;
  level: RiskLevel;
}

export interface InputFacts {
  message: string;
  unknownSender: boolean;
}
